const fs = require("fs-extra");
const { chromium } = require("playwright");
const { Parser } = require("json2csv");

const dork = "interior USA";
const maxPages = 190;

const bingPagesLoaded = [];
const bingPagesFile = "bingPages.json";
const progressFile = "progress.json";
const csvFile = "output.csv";

let progress = { page: 0, index: 0, done: [], failed: [] };
if (fs.existsSync(progressFile)) {
  progress = fs.readJsonSync(progressFile);
}

function filterEmails(emails) {
  const validEmailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/;
  const junkDomains = ["sentry.io", "example.com", "localhost"];
  return [...new Set(emails.filter(email =>
    validEmailRegex.test(email) &&
    !junkDomains.some(j => email.includes(j)) &&
    !email.includes("user") &&
    !email.includes("test")
  ))];
}

function filterPhones(phones) {
  const phoneRegex = /(?:\+?\d{1,4}[ \-]?)?(?:\(?\d{2,5}\)?[ \-]?)?\d{3,5}[ \-]?\d{3,5}/g;
  const cleaned = new Set();
  for (const phone of phones) {
    const matches = phone.match(phoneRegex);
    if (!matches) continue;
    matches.forEach(p => {
      const digits = p.replace(/[^\d+]/g, "");
      if (
        digits.length >= 9 && digits.length <= 12 &&
        !/^(0{4,}|1{4,}|9{4,})$/.test(digits) &&
        !digits.includes("2147483648")
      ) cleaned.add(digits);
    });
  }
  return [...cleaned];
}

const extractEmails = (text) => {
  const found = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}/g) || [];
  return filterEmails(found);
};

const extractPhones = (text) => {
  const found = text.match(/(?:\+?\d{1,4}[-.\s]?)?(?:\(?\d{2,5}\)?[-.\s]?)?\d{3,5}[-.\s]?\d{3,5}/g) || [];
  return filterPhones(found);
};

const extractSocialUrls = (html) => {
  const regex = /(https?:\/\/(?:www\.)?(facebook|instagram|linkedin|twitter|youtube)\.[^'"<>\s]+)/gi;
  return [...new Set([...html.matchAll(regex)].map(m => m[1]))];
};

const extractAddresses = (text) => {
  const regex = /\d{1,5}\s+(?:[A-Za-z0-9.\-]+\s){1,6}(Street|St|Road|Rd|Ave|Avenue|Block|Sector|Colony|Nagar|Plaza)/gi;
  return [...new Set(text.match(regex) || [])];
};

const extractHeadings = (html, level) => {
  const regex = new RegExp(`<${level}[^>]*>(.*?)<\\/${level}>`, "gi");
  return [...html.matchAll(regex)].map(m => m[1].replace(/<[^>]+>/g, "").trim());
};

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function getBingLinks(browser) {
  const context = await browser.newContext();
  const page = await context.newPage();
  const results = [];

  for (let i = progress.page; i < maxPages; i++) {
    const offset = i * 10;
    const url = `https://www.bing.com/search?q=${encodeURIComponent(dork)}&first=${offset}`;
    const pageNum = i + 1;
    console.log(`🔍 Loading Bing page ${pageNum}...`);
    bingPagesLoaded.push({ page: pageNum, timestamp: new Date().toISOString() });

    let success = false;
    for (let tryCount = 0; tryCount < 3; tryCount++) {
      try {
        await page.goto(url, { waitUntil: "domcontentloaded", timeout: 15000 });
        await page.waitForSelector("li.b_algo h2 a", { timeout: 10000 });
        await delay(2000 + Math.random() * 2000);
        success = true;
        break;
      } catch {
        console.log(`⚠️ Retry loading Bing page ${pageNum} (${tryCount + 1}/3)`);
        await delay(4000);
      }
    }

    if (success) {
      const links = await page.$$eval("li.b_algo h2 a", anchors => anchors.map(a => a.href));
      results.push(...links.filter(link => link.startsWith("http")));
    } else {
      console.log(`❌ Failed to load Bing page ${pageNum}`);
    }

    progress.page = i + 1;
    await fs.writeJson(progressFile, progress, { spaces: 2 });
  }

  await page.close();
  return [...new Set(results)];
}

async function scrapeWebsite(browser, url) {
  try {
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
    await delay(3000 + Math.random() * 2000);

    const content = await page.content();
    const text = await page.textContent("body");

    const emails = extractEmails(text);
    const phones = extractPhones(text);
    const socials = extractSocialUrls(content);
    const addresses = extractAddresses(text);
    const h1 = extractHeadings(content, "h1");
    const h2 = extractHeadings(content, "h2");
    const h3 = extractHeadings(content, "h3");

    await page.close();

    console.log(`✅ Scanned: ${url}`);
    return {
      url,
      emails: emails.join(", "),
      phones: phones.join(", "),
      socials: socials.join(", "),
      addresses: addresses.join(", "),
      h1: h1.join(" | "),
      h2: h2.join(" | "),
      h3: h3.join(" | "),
    };
  } catch (err) {
    console.log(`❌ Failed: ${url} → ${err.message}`);
    return null;
  }
}

async function scrape() {
  console.log(`🚀 Scraper started → Bing Dork: ${dork}`);
  const browser = await chromium.launch({ headless: false, slowMo: 80 });

  const links = await getBingLinks(browser);
  const results = [];

  for (let i = 0; i < progress.failed.length; i++) {
    const url = progress.failed[i];
    if (progress.done.includes(url)) continue;
    console.log(`🔁 Retrying: ${url}`);
    const data = await scrapeWebsite(browser, url);
    if (data) {
      results.push(data);
      progress.done.push(url);
      progress.failed.splice(i, 1);
      i--;
    } else {
      console.log(`❌ Still failed: ${url}`);
    }
    await fs.writeJson(progressFile, progress, { spaces: 2 });
  }

  for (let i = progress.index; i < links.length; i++) {
    const url = links[i];
    if (progress.done.includes(url)) {
      console.log(`⏭ Skipping: ${url}`);
      continue;
    }

    const data = await scrapeWebsite(browser, url);
    if (data) {
      results.push(data);
      progress.done.push(url);
    } else {
      progress.failed.push(url);
    }

    progress.index = i + 1;
    await fs.writeJson(progressFile, progress, { spaces: 2 });
  }

  await browser.close();

  let existingResults = [];
  if (fs.existsSync(csvFile)) {
    const csvData = await fs.readFile(csvFile, "utf8");
    const rows = csvData.split("\n");
    const headers = rows.shift().split(",");
    for (const row of rows) {
      if (!row.trim()) continue;
      const values = row.split(",");
      const obj = {};
      headers.forEach((h, i) => obj[h] = values[i]);
      existingResults.push(obj);
    }
  }

  const allResultsMap = new Map();
  [...existingResults, ...results].forEach(r => allResultsMap.set(r.url, r));
  const allResults = Array.from(allResultsMap.values());

  const parser = new Parser();
  const csv = parser.parse(allResults);
  await fs.writeFile(csvFile, csv);
  console.log(`\n✅ Done! Scraped ${results.length} websites → Saved to output.csv`);

  await fs.writeJson(bingPagesFile, bingPagesLoaded, { spaces: 2 });
}

scrape();
